-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 26, 2024 at 08:29 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ukk_perpus`
--

-- --------------------------------------------------------

--
-- Table structure for table `buku`
--

CREATE TABLE `buku` (
  `id_buku` int(11) NOT NULL,
  `id_kategori` int(11) DEFAULT NULL,
  `judul` varchar(255) DEFAULT NULL,
  `penulis` varchar(255) DEFAULT NULL,
  `penerbit` varchar(255) DEFAULT NULL,
  `tahun_terbit` varchar(255) DEFAULT NULL,
  `gambar` varchar(255) NOT NULL,
  `deskripsi` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `buku`
--

INSERT INTO `buku` (`id_buku`, `id_kategori`, `judul`, `penulis`, `penerbit`, `tahun_terbit`, `gambar`, `deskripsi`) VALUES
(1, 1, 'Holy Mother', ' Akiyoshi Rikako', 'Penerbit Haru', '2019', 'the boys.jpg', 'menceritakan tentang kisah seorang ibu yang rela melakukan apa saja untuk melindungi kehidupan putrinya. Tanaka Makoto selaku tokoh utama adalah seorang ibu dan juga pelajar tingkat SMA yang memiliki masa lalu kelam.menceritakan tentang kisah seorang ibu yang rela melakukan apa saja untuk melindungi kehidupan putrinya. Tanaka Makoto selaku tokoh utama adalah seorang ibu dan juga pelajar tingkat SMA yang memiliki masa lalu kelam.'),
(2, 1, 'raplay', 'Stan Lee', '', '2000', 'doraemon.jpg', NULL),
(3, 1, 'raplay', 'Stan Lee', 'Penerbit Haru', '2016', 'Demon slayer tanjiro wallpaper 1920x1080 laptop desktop 4k hd wpp 🎀.jfif', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `kategori`
--

CREATE TABLE `kategori` (
  `id_kategori` int(11) NOT NULL,
  `kategori` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `kategori`
--

INSERT INTO `kategori` (`id_kategori`, `kategori`) VALUES
(1, 'Horror'),
(2, 'Fiksi Ilmiah'),
(3, 'Comic');

-- --------------------------------------------------------

--
-- Table structure for table `peminjaman`
--

CREATE TABLE `peminjaman` (
  `id_peminjaman` int(11) NOT NULL,
  `id_user` int(11) DEFAULT NULL,
  `id_buku` int(11) DEFAULT NULL,
  `tanggal_peminjaman` varchar(255) DEFAULT NULL,
  `tanggal_pengembalian` varchar(255) DEFAULT NULL,
  `status_peminjaman` enum('dipinjam','dikembalikan') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `peminjaman`
--

INSERT INTO `peminjaman` (`id_peminjaman`, `id_user`, `id_buku`, `tanggal_peminjaman`, `tanggal_pengembalian`, `status_peminjaman`) VALUES
(1, 16, 1, '', '', 'dipinjam'),
(2, 19, 1, '', '', 'dipinjam'),
(3, 19, 1, '', '', 'dipinjam'),
(4, 24, 1, '', '', 'dipinjam');

-- --------------------------------------------------------

--
-- Table structure for table `ulasan`
--

CREATE TABLE `ulasan` (
  `id_ulasan` int(11) NOT NULL,
  `id_user` int(11) DEFAULT NULL,
  `id_buku` int(11) DEFAULT NULL,
  `ulasan` text DEFAULT NULL,
  `rating` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ulasan`
--

INSERT INTO `ulasan` (`id_ulasan`, `id_user`, `id_buku`, `ulasan`, `rating`) VALUES
(3, 20, 1, 'HUJAN. novel ini mengisahkan percintaan dan perjuangan hidup seorang perempuan bernama lail. ketika lail baru berusia 13 tahun, dirinya harus menjadi seorang anak yatim piatu di hari pertama ia sekolah ada sebuah bencana gunung meletus dan gempa dahsyat sehingga menhancurkan kota di mana ia menetap bahkan merenggut nyawa ibu serta ayah lail. selama kurang lebih satu tahun dari bencana tersebut lail dan esok tinggal di sebuah pengungsian keduanya pun kerap kali membantu petugas pengungsian keduanya pun kerap kali membantu petugas pengungsian', 6);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id_user` int(11) NOT NULL,
  `nama` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `alamat` text DEFAULT NULL,
  `no_telepon` varchar(255) DEFAULT NULL,
  `level` enum('admin','petugas','peminjam') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `nama`, `username`, `password`, `email`, `alamat`, `no_telepon`, `level`) VALUES
(5, 'siswa 1', 'peminjam', '82053eb600f114c3315ec6a4eedcad5b', 'peminjam@gmail.com', 'cimahi', '0897654', 'peminjam'),
(8, 'peminjaman', 'peminjam', '82053eb600f114c3315ec6a4eedcad5b', 'peminjam@gmail.com', 'cimahi utara', '0891313', 'peminjam'),
(9, 'raya', 'admin', '81dc9bdb52d04dc20036dbd8313ed055', '', 'Cibatu City', '645645654465', 'admin'),
(10, 'salsa', 'salsa', '202cb962ac59075b964b07152d234b70', '', 'Tegalaja Pedalaman', '4565465465465', 'peminjam'),
(11, 'aa', 'aaa', '47bce5c74f589f4867dbd57e9ca9f808', '', 'aasdsa', 'aaa', 'peminjam'),
(12, 'bimax', 'bimax', 'fe8e9e1d5e2aeafdea1664f209675fc1', '', 'araby', '08644654565345', 'admin'),
(16, 'raya', 'admin', '202cb962ac59075b964b07152d234b70', '', '12356', '0891313', 'peminjam'),
(18, 'rapli', 'admin', '202cb962ac59075b964b07152d234b70', '', '123', '0891313', 'admin'),
(19, 'peminjam 1', 'rapli', '202cb962ac59075b964b07152d234b70', '', '123', '0891313', 'peminjam'),
(20, 'rapli', 'admin2', '202cb962ac59075b964b07152d234b70', '', '234', '0891313', 'admin'),
(21, 'admin1', 'admin1', 'e00cf25ad42683b3df678c61f42c6bda', '', 'xgvfddggs', '3424234223', 'admin'),
(24, 'a rapli', 'arapli', '81dc9bdb52d04dc20036dbd8313ed055', '', '1234', '08789455432', 'admin'),
(25, 'rapli', 'rapli', '202cb962ac59075b964b07152d234b70', '', '123', '08913131', 'petugas'),
(26, 'rapli', 'adminn', '202cb962ac59075b964b07152d234b70', '', '3r', '08789455432', ''),
(27, 'rama', 'papat', 'd93591bdf7860e1e4ee2fca799911215', '', 'cipeyeum', '0812341234', 'peminjam'),
(28, 'apin', 'ipul', 'd93591bdf7860e1e4ee2fca799911215', 'rapli@gmail.com', 'cipeyeum', '098976', 'petugas');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `buku`
--
ALTER TABLE `buku`
  ADD PRIMARY KEY (`id_buku`),
  ADD KEY `id_kategori` (`id_kategori`);

--
-- Indexes for table `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`id_kategori`);

--
-- Indexes for table `peminjaman`
--
ALTER TABLE `peminjaman`
  ADD PRIMARY KEY (`id_peminjaman`),
  ADD KEY `id_user` (`id_user`),
  ADD KEY `id_buku` (`id_buku`);

--
-- Indexes for table `ulasan`
--
ALTER TABLE `ulasan`
  ADD PRIMARY KEY (`id_ulasan`),
  ADD KEY `id_user` (`id_user`),
  ADD KEY `id_buku` (`id_buku`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `buku`
--
ALTER TABLE `buku`
  MODIFY `id_buku` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `kategori`
--
ALTER TABLE `kategori`
  MODIFY `id_kategori` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `peminjaman`
--
ALTER TABLE `peminjaman`
  MODIFY `id_peminjaman` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `ulasan`
--
ALTER TABLE `ulasan`
  MODIFY `id_ulasan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `buku`
--
ALTER TABLE `buku`
  ADD CONSTRAINT `buku_ibfk_1` FOREIGN KEY (`id_kategori`) REFERENCES `kategori` (`id_kategori`);

--
-- Constraints for table `peminjaman`
--
ALTER TABLE `peminjaman`
  ADD CONSTRAINT `peminjaman_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`),
  ADD CONSTRAINT `peminjaman_ibfk_2` FOREIGN KEY (`id_buku`) REFERENCES `buku` (`id_buku`);

--
-- Constraints for table `ulasan`
--
ALTER TABLE `ulasan`
  ADD CONSTRAINT `ulasan_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`),
  ADD CONSTRAINT `ulasan_ibfk_2` FOREIGN KEY (`id_buku`) REFERENCES `buku` (`id_buku`),
  ADD CONSTRAINT `ulasan_ibfk_3` FOREIGN KEY (`id_user`) REFERENCES `user` (`id_user`),
  ADD CONSTRAINT `ulasan_ibfk_4` FOREIGN KEY (`id_buku`) REFERENCES `buku` (`id_buku`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
