<?php
// Include the database connection
include_once 'koneksi.php';

// Cek apakah pengguna sudah login dan memiliki akses yang tepat
if (!isset($_SESSION['user']) || $_SESSION['user']['level'] !== 'admin') {
    include '404.php';
    exit();
}

// Function to fetch users from the database
function fetchUsers($pdo) {
    try {
        // Hanya ambil pengguna yang bukan admin
        $stmt = $pdo->prepare("SELECT id_user, nama, level FROM user WHERE level != 'admin'");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        die('Query failed: ' . $e->getMessage());
    }
}

// Function to handle role promotion
function promoteUser($pdo, $user_id) {
    try {
        $stmt = $pdo->prepare("UPDATE user SET level = 'petugas' WHERE id_user = :id_user");
        $stmt->execute(['id_user' => $user_id]);
        return "User promoted to petugas successfully.";
    } catch (PDOException $e) {
        return "Failed to promote user: " . $e->getMessage();
    }
}

// Function to handle role demotion
function demoteUser($pdo, $user_id, $new_role) {
    try {
        $stmt = $pdo->prepare("UPDATE user SET level = :new_role WHERE id_user = :id_user");
        $stmt->execute(['new_role' => $new_role, 'id_user' => $user_id]);
        return "User role updated successfully.";
    } catch (PDOException $e) {
        return "Failed to update user role: " . $e->getMessage();
    }
}

// Function to handle removing 'petugas' role and setting to 'peminjam'
function removePetugas($pdo, $user_id) {
    try {
        $stmt = $pdo->prepare("UPDATE user SET level = 'peminjam' WHERE id_user = :id_user");
        $stmt->execute(['id_user' => $user_id]);
        return "Petugas role removed and changed to Peminjam successfully.";
    } catch (PDOException $e) {
        return "Failed to remove petugas role: " . $e->getMessage();
    }
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        $action = $_POST['action'];
        $user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : 0;
        $new_role = isset($_POST['new_role']) ? $_POST['new_role'] : '';
        $message = '';

        if ($user_id > 0) {
            switch ($action) {
                case 'promote':
                    $message = promoteUser($pdo, $user_id);
                    break;
                case 'demote':
                    if ($new_role) {
                        $message = demoteUser($pdo, $user_id, $new_role);
                    } else {
                        $message = 'New role is required.';
                    }
                    break;
                case 'remove_petugas':
                    $message = removePetugas($pdo, $user_id);
                    break;
                default:
                    $message = 'Invalid action.';
                    break;
            }
        } else {
            $message = 'Invalid user ID.';
        }

        // Redirect ke halaman yang sama dengan pesan di URL
        header('Location: index.php?page=kelola_level&message=' . urlencode($message));
        exit();
    }
}

// Fetch users for display
$users = fetchUsers($pdo);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Level</title>
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
    <link href="css/styles.css" rel="stylesheet" />
</head>
<body>
    <div class="container mt-4">
        <h2>Kelola Level</h2>
        <!-- Menampilkan pesan dari URL -->
        <?php if (isset($_GET['message'])): ?>
            <div class="alert alert-info">
                <?php echo htmlspecialchars($_GET['message']); ?>
            </div>
        <?php endif; ?>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nama</th>
                    <th>Level Saat ini</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $user): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($user['id_user']); ?></td>
                        <td><?php echo htmlspecialchars($user['nama']); ?></td>
                        <td><?php echo htmlspecialchars($user['level']); ?></td>
                        <td>
                            <?php if ($user['level'] === 'admin'): ?>
                                <form action="kelola_level.php" method="post" style="display:inline;">
                                    <input type="hidden" name="action" value="demote">
                                    <input type="hidden" name="user_id" value="<?php echo htmlspecialchars($user['id_user']); ?>">
                                    <select name="new_role" required>
                                        <option value="peminjam">Set as Peminjam</option>
                                        <option value="petugas">Set as Petugas</option>
                                    </select>
                                    <button type="submit" class="btn btn-warning">Remove Admin Role</button>
                                </form>
                            <?php elseif ($user['level'] === 'petugas'): ?>
                                <form action="kelola_level.php" method="post" style="display:inline;">
                                    <input type="hidden" name="action" value="remove_petugas">
                                    <input type="hidden" name="user_id" value="<?php echo htmlspecialchars($user['id_user']); ?>">
                                    <button type="submit" class="btn btn-danger">Remove Petugas Role</button>
                                </form>
                            <?php else: ?>
                                <form action="kelola_level.php" method="post" style="display:inline;">
                                    <input type="hidden" name="action" value="promote">
                                    <input type="hidden" name="user_id" value="<?php echo htmlspecialchars($user['id_user']); ?>">
                                    <button type="submit" class="btn btn-primary">Jadikan Petugas</button>
                                </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
</body>
</html>
