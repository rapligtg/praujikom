<?php
session_start();
$koneksi = mysqli_connect('localhost','root','','UKK_PERPUS');
?>

<?php
try {
    $pdo = new PDO('mysql:host=localhost;dbname=UKK_PERPUS', 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die('Connection failed: ' . $e->getMessage());
}
?>
