<?php
if (isset($_POST['submit'])) {
    // Melindungi input dari serangan SQL Injection
    $KategoriID = mysqli_real_escape_string($koneksi, $_POST['id_kategori']);
    $judul = mysqli_real_escape_string($koneksi, $_POST['judul']);
    $penulis = mysqli_real_escape_string($koneksi, $_POST['penulis']);
    $penerbit = mysqli_real_escape_string($koneksi, $_POST['penerbit']);
    $tahun_terbit = mysqli_real_escape_string($koneksi, $_POST['tahun_terbit']);
    $gambar = mysqli_real_escape_string($koneksi, $_FILES['gambar']['name']);
  
    // Proses upload gambar
    $gambar_tmp = $_FILES['gambar']['tmp_name']; // Mendapatkan file sementara dari gambar yang diupload
    $gambar_size = $_FILES['gambar']['size']; // Mendapatkan ukuran file
    $gambar_err = $_FILES['gambar']['error']; // Mendapatkan error jika ada
  
    // Jika tidak ada error saat upload gambar
    if ($gambar_err === UPLOAD_ERR_OK) {
      // Menentukan direktori tempat menyimpan gambar
      $upload_dir = __DIR__ . '/assets/img/';
      // Menentukan jalur lengkap file yang akan disimpan
      $gambar_path = $upload_dir . basename($gambar);
  
      // Memindahkan file gambar dari direktori sementara ke direktori tujuan
      if (move_uploaded_file($gambar_tmp, $gambar_path)) {
        // Membuat query untuk menyimpan data ke database
        $query = "INSERT INTO buku(id_kategori, judul, penulis, penerbit, tahun_terbit, gambar) 
                  VALUES('$KategoriID', '$judul', '$penulis', '$penerbit', '$tahun_terbit', '$gambar')";
  
        // Menjalankan query
        $result = mysqli_query($koneksi, $query);
  
        // Mengecek apakah query berhasil dijalankan
        if ($result) {
          echo '<script>alert("Penambahan data berhasil.");</script>';
          exit;
        } else {
          echo '<script>alert("Penambahan data gagal: ' . mysqli_error($koneksi) . '");</script>';
        }
      } else {
        echo '<script>alert("Penambahan file gagal.");</script>';
      }
    } else {
      echo '<script>alert("File error, coba ulangi lagi. Error: ' . $gambar_err . '");</script>';
    }
   
  }
  ?>


<h1 class="m-4">Buku</h1>
<div class="card m-3">
    <div class="card-body p-5">
        <div class="row">
            <div class="col-md-12">
                <form method="post" enctype="multipart/form-data">
                    <div class="row mb-3">
                        <div class="col-md-2">Kategori</div>
                        <div class="col-md-8">
                            <select name="id_kategori" class="form-control">
                                <?php
                                    $kat = mysqli_query($koneksi, "SELECT * FROM kategori");
                                    while($kategori = mysqli_fetch_array($kat)){
                                ?>
                                <option value="<?php echo htmlspecialchars($kategori['id_kategori']); ?>">
                                    <?php echo htmlspecialchars($kategori['kategori']); ?>
                                </option>
                                <?php
                                    }
                                ?>
                            </select>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-2">Judul</div>
                        <div class="col-md-8"><input type="text" class="form-control" name="judul" required></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-2">Penulis</div>
                        <div class="col-md-8"><input type="text" class="form-control" name="penulis" required></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-2">Penerbit</div>
                        <div class="col-md-8"><input type="text" class="form-control" name="penerbit" required></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-2">Tahun Terbit</div>
                        <div class="col-md-8"><input type="text" class="form-control" name="tahun_terbit" required></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-2">Deskripsi</div>
                        <div class="col-md-8">
                            <textarea name="deskripsi" rows="5" class="form-control" required></textarea>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-2">Gambar</div>
                        <div class="col-md-8">
                            <input type="file" class="form-control" name="gambar" required>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-2"></div>
                        <div class="col-md-8">
                            <button type="submit" class="btn btn-primary" name="submit" value="submit">Simpan</button>
                            <button type="reset" class="btn btn-secondary">Reset</button>
                            <a href="?page=buku" class="btn btn-danger">Kembali</a>
                        </div>
                    </div>
                </form>  
            </div>
        </div>
    </div>
</div>
