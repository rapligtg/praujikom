<!-- /*untuk mengarahkan user yang belum login kehalaman login*/ -->
<?php
     include "koneksi.php";
    if(!isset($_SESSION['user'])){
       header('location:login.php');
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman dengan Warna Latar Belakang</title>
    <style>
        body {
            background-color: #f0f0f0; /* Ganti dengan warna yang diinginkan */
        }
    </style>
</head>
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Perpustakaan Digital</title>
        <link href="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/style.min.css" rel="stylesheet" />
        <link href="css/styles.css" rel="stylesheet" />
        <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    </head>
    <body class="sb-nav-fixed">
        <nav class="sb-topnav navbar navbar-expand navbar-dark bg-dark">
            <!-- Navbar Brand-->
            <a class="navbar-brand ps-3" href="index.php">Perpustakaan Digital</a>
            <!-- Sidebar Toggle-->
            <button class="btn btn-link btn-sm order-1 order-lg-0 me-4 me-lg-0" id="sidebarToggle" href="#!"><i class="fas fa-bars"></i></button>
            </form>
        </nav>
        <div id="layoutSidenav">
            <div id="layoutSidenav_nav">
                <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">
                            <div class="sb-sidenav-menu-heading">Core</div>
                            <a class="nav-link" href="?">
                                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Perpustakan Digital
                            </a>
                            <div class="sb-sidenav-menu-heading">Navigasi</div>
                          
            <?php
            // Pastikan session sudah dimulai sebelumnya
            // session_start();

            // Ambil level pengguna dari session
            $user_level = isset($_SESSION['user']['level']) ? $_SESSION['user']['level'] : '';

            // Menu berdasarkan level pengguna
            if ($user_level == 'admin') {
                ?>
                <!-- Administrator Navigation -->
                <li class="nav-item">
                    <a class="nav-link" href="?page=kategori">
                        <i class="fas fa-book-open"></i>
                        <span>Kategori Buku</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="?page=buku">
                        <i class="fas fa-fw fa-solid fa-book"></i>
                        <span>Buku</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="?page=peminjaman">
                        <i class="fas fa-book-open"></i>
                        <span>Peminjaman</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="?page=ulasan">
                        <i class="fas fa-fw fa-regular fa-comment"></i>
                        <span>Ulasan</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="?page=kelola_level">
                        <i class="fas fa-fw fa-address-book"></i>
                        <span>User</span>
                    </a>
                </li>
                <?php
            } elseif ($user_level == 'petugas') {
                ?>
                <!-- Petugas Navigation -->
                <li class="nav-item">
                    <a class="nav-link" href="?page=buku">
                        <i class="fas fa-fw fa-solid fa-book"></i>
                        <span>Buku</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="?page=peminjaman">
                        <i class="fas fa-book-open"></i>
                        <span>Peminjaman</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="?page=ulasan">
                        <i class="fas fa-fw fa-regular fa-comment"></i>
                        <span>Ulasan</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="?page=laporan">
                        <i class="fas fa-fw fa-regular fa-comment"></i>
                        <span>Catatan Peminjaman</span>
                    </a>
                </li>
                <?php
            } elseif ($user_level == 'peminjam') {
                ?>
                <!-- Peminjam Navigation -->
                <li class="nav-item">
                    <a class="nav-link" href="?page=buku">
                        <i class="fas fa-fw fa-solid fa-book"></i>
                        <span>Buku</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="?page=peminjaman">
                        <i class="fas fa-book-open"></i>
                        <span>Peminjaman</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="?page=ulasan">
                        <i class="fas fa-fw fa-regular fa-comment"></i>
                        <span>Ulasan</span>
                    </a>
                </li>
                <?php
            }
            ?>
                            <a class="nav-link" href="logout.php">
                                <div class="sb-nav-link-icon"><i class="fa fa-power-off"></i></div>
                                Logout</a>
                        </div>
                    </div>
                    <div class="sb-sidenav-footer">
                        <div class="small">Logged in as:</div>
                        <?php echo $_SESSION['user']['nama'];?>
                    </div>
                </nav>
            </div>
            <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid px-4">
                        <?php

                        $page = isset($_GET['page']) ? $_GET['page'] : 'home';
                        if(file_exists($page . '.php')){
                            include $page . '.php';
                        }else{
                            include '404.php';
                        }
                        ?>
                        </div>
                    </div>
                </main>
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid px-4">
                        </div>
                    </div>
                </footer>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
        <script src="assets/demo/chart-area-demo.js"></script>
        <script src="assets/demo/chart-bar-demo.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js" crossorigin="anonymous"></script>
        <script src="js/datatables-simple-demo.js"></script>
    </body>
</html>
